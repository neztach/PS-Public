$Modules = @(
   "$PSScriptRoot\MSOnline\1.1.183.66\MSOnline.psd1"
   "$PSScriptRoot\MSOnline\1.1.183.66\MSOnlineExtended.psd1"
   "$PSScriptRoot\PSWinDocumentation.O365\0.0.7\PSWinDocumentation.O365.psd1"
)
foreach ($_ in $Modules) {
   Import-Module $_ -Verbose:$false -Force
}
