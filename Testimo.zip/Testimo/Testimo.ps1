$Modules = @(
   "$PSScriptRoot\PSWriteHTML\1.8.0\PSWriteHTML.psd1"
   "$PSScriptRoot\PSEventViewer\1.0.22\PSEventViewer.psd1"
   "$PSScriptRoot\GPOZaurr\0.0.159\GPOZaurr.psd1"
   "$PSScriptRoot\ADEssentials\0.0.164\ADEssentials.psd1"
   "$PSScriptRoot\PSWinDocumentation.DNS\0.0.10\PSWinDocumentation.DNS.psd1"
   "$PSScriptRoot\PSSharedGoods\0.0.265\PSSharedGoods.psd1"
   "$PSScriptRoot\Testimo\0.0.85\Testimo.psd1"
)
foreach ($_ in $Modules) {
   Import-Module $_ -Verbose:$false -Force
}
