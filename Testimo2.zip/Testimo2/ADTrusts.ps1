﻿Show-WinADTrust -Online -FilePath "C:\users\sa-jastep\Desktop\MigrationHelper\ADTrusts.html" -Verbose {
    TableHeader -Names 'TrustBase', 'TrustType', 'TrustTypeAD' -Color Blue -Title 'Types'
    TableCondition -Name 'TrustDirection' -BackgroundColor red -Color white -Value 'Bidirectional' -Operator eq -ComparisonType string
    TableCondition -Name 'Level' -BackgroundColor blue -Color white -Value 0 -Operator eq -ComparisonType number
}
