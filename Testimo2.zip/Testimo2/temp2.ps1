﻿$mypath = (Get-Item -Path .).FullName
$t=@()
$Modules = Get-ChildItem -Path "$myPath\DiscoverAD\" -Filter *.psd1 -Recurse -Depth 2 -File | Select-Object -Property LastWriteTime,Name,Fullname | Group-Object -Property Name
ForEach ($Module in $Modules){
    If ($Module.Count -gt 1){
        $s=($Module.GetEnumerator() | sort -Property LastWriteTime | select -last 1).Value
        $t += $s
    } else {
        $s=($Module.GetEnumerator()).Value
        $t += $s
    }
}
$t

#%{$t+=[pscustomobject]@{LastWriteTime=$_.LastWriteTime;PSParentPath=$_.PSParentPath.toString();PSChildName=$_.PSChildName;FullName=$_.FullName}};$t