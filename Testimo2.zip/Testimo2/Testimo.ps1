$Modules = @(
   "$PSScriptRoot\MSOnline\1.1.183.66\MSOnline.psd1"
   "$PSScriptRoot\MSOnline\1.1.183.66\MSOnlineExtended.psd1"
   "$PSScriptRoot\PSWriteHTML\1.8.0\PSWriteHTML.psd1"
   "$PSScriptRoot\PSEventViewer\1.0.22\PSEventViewer.psd1"
   "$PSScriptRoot\GPOZaurr\0.0.159\GPOZaurr.psd1"
   "$PSScriptRoot\ADEssentials\0.0.164\ADEssentials.psd1"
   "$PSScriptRoot\DSInternals\4.9\DSInternals.psd1"
   "$PSScriptRoot\PSWinDocumentation.O365\0.0.7\PSWinDocumentation.O365.psd1"
   "$PSScriptRoot\PSWinDocumentation.AWS\0.0.4\PSWinDocumentation.AWS.psd1"
   "$PSScriptRoot\PSWinDocumentation.AD\0.1.20\PSWinDocumentation.AD.psd1"
   "$PSScriptRoot\PSWinDocumentation.DNS\0.0.10\PSWinDocumentation.DNS.psd1"
   "$PSScriptRoot\PSSharedGoods\0.0.265\PSSharedGoods.psd1"
   "$PSScriptRoot\PSWriteExcel\0.1.9\PSWriteExcel.psd1"
   "$PSScriptRoot\PSWriteWord\1.1.9\PSWriteWord.psd1"
   "$PSScriptRoot\PSWinDocumentation\0.5.3\PSWinDocumentation.psd1"
   "$PSScriptRoot\Testimo\0.0.85\Testimo.psd1"
)
foreach ($_ in $Modules) {
   Import-Module $_ -Verbose:$false -Force
}
