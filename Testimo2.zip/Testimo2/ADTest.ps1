﻿#region Prepare PS env
$mypath         = (Get-Item -Path .).FullName
$CurrentProfile = Test-Path -Path $PROFILE
$ProfileBase    = Split-Path -Path $PROFILE
$ModulePath     = "$ProfileBase\Modules"
$MyModules      = "$myPath\DiscoverAD\"
$Modules        = Get-ChildItem -Path "$myPath\DiscoverAD\" -Filter '*.psd1' -Recurse -Depth 2 -File | 
                  Group-Object -Property {$_.Name} | 
                  ForEach-Object {$_.Group | Sort-Object -Property LastWriteTime -Descending | Select-Object -First 1} | 
                  Select-Object -Property Name,Fullname

If ($CurrentProfile -eq $false){
    New-Item -Path $Profile -ItemType File -Force
    Get-Content -Path "$myPath\Profile\profile.txt" | Add-Content -Path $Profile -Encoding UTF8
}

           
### Create Modules folder now that we have a profile folder
If ((Test-Path -Path $ModulePath) -eq $false){New-Item -Path $ModulePath -ItemType Directory}

### Copy modules and/or Import-Modules
Function Get-ModuleCheck {
    [CmdletBinding()]
    Param ([switch]$copy)
    $done                         = $false
    [string]$destinationDirectory = $ModulePath
    #$CurrentModules               = Get-ChildItem -Path $destinationDirectory -Directory | Select-Object -Property Name,Fullname
    $CurrentModules               = Get-Module -ListAvailable | Select-Object -Property Name | Sort-Object Name | Select-Object -ExpandProperty Name
    $MyModulesDir                 = Get-ChildItem -Path $MyModules -Directory
    $mCount                       = 0
    ForEach ($myModDir in $MyModulesDir){
        If ($myModDir.Name -notin $CurrentModules){
            [string]$sourceDirectory = $myModDir.Fullname
            If ($copy){
                Copy-Item -Force -Recurse -Verbose -Path $sourceDirectory -Destination $destinationDirectory
            } else {
                Write-Verbose -Message "$($myModDir.Name) Not Found."
            }
        } Else {
            $mCount++
            "$($myModDir.Name) Found."
        }
    }
    If ($mCount = 0){
        $done = $true
        ForEach ($Mod in $Modules){
            [string]$modName = $Mod.Name.TrimEnd('.psd1')
            Import-Module -Name $modName -Verbose:$true <#-Force#>
        }
    } Else {
        ForEach ($Mod in $Modules){
            [string]$modName = $Mod.Fullname
            Import-Module -Name $modName -Verbose:$true <#-Force#>
        }
    }
    Return $done
}

#ForEach ($_ in $Modules) {Import-Module -Name $_ -Verbose:$true <#-Force#>}
### PROFILE If ((Test-Path -Path $PROFILE) -eq $false){New-Item -Path $Profile -ItemType File -Force;$MyProfile | Out-File -FilePath $PROFILE -Encoding utf8} Else {$MyProfile | Out-File -FilePath $PROFILE -Append -Encoding utf8}

### Copy our Modules
Get-ModuleCheck -copy

#endregion Prepare PS env

