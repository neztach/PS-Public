EnlighterJS.init("pre", "code", {
    language: "powershell", // - use javascript as default language
    theme: "enlighter", // - use theme "enlighter" as default theme
    indent: 2 // - replace tabs with 2 spaces
});