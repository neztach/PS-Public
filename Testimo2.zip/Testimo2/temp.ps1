﻿Import-Module -Name Testimo
$SaveFilePath = "C:\Users\sa-jastep\Desktop\MigrationHelper"

### AD Health Check
$Sources = @(
    'ForestBackup',
    'ForestReplication',
    'ForestReplicationStatus',
    'ForestSites',
    'ForestSiteLinks',
    'ForestSiteLinksConnections',
    'ForestRoles',
    'ForestOrphanedAdmins',
    #'ForestObjectsWithConflict',
    'DomainRoles',
    'DomainPasswordComplexity',
    #'DomainTrusts',
    'DomainOrphanedForeignSecurityPrincipals',
    'DomainDNSForwaders',
    'DCInformation',
    'DCOperatingSystem',
    'DCServices',
    'DCPingable',
    'DCRDPSecurity',
    'DCWindowsRolesAndFeatures',
    'DCDnsResolveInternal',
    'DCDnsNameServes'
)
<# Full Source List
    ### Forest
    'ForestBackup'
    'ForestReplication'
    'ForestReplicationStatus'
    'ForestOptionalFeatures'
    'ForestSites'
    'ForestSiteLinks'
    'ForestSiteLinksConnections'
    'ForestRoles'
    'ForestOrphanedAdmins'
    'ForestObjectsWithConflict'
    'ForestTombstoneLifetime'
    
    ### Domain
    'DomainRoles'
    'DomainWellKnownFolders'
    'DomainPasswordComplexity'
    'DomainGroupPolicyMissingPermissions'
    'DomainGroupPolicyPermissionConsistency'
    'DomainGroupPolicyOwner'
    'DomainGroupPolicyPermissionUnknown'
    'DomainGroupPolicyADM'
    'DomainTrusts'
    'DomainOrphanedForeignSecurityPrincipals'
    'DomainOrganizationalUnitsEmpty'
    'DomainOrganizationalUnitsProtected'
    'DomainDNSScavengingForPrimaryDNSServer'
    'DomainDNSForwaders'
    'DomainDnsZonesAging'
    'DomainKerberosAccountAge'
    'DomainSecurityGroupsAccountOperators'
    'DomainSecurityGroupsSchemaAdmins'
    'DomainSecurityUsers'
    'DomainSecurityUsersAcccountAdministrator'
    'DomainSecurityKRBGT'
    'DomainSysVolDFSR'
    'DomainDNSZonesForest0ADEL'
    'DomainDNSZonesDomain0ADEL'
    'DomainDHCPAuthorized'
    'DomainComputersUnsupported'
    'DomainComputersUnsupportedMainstream'
    'DomainExchangeUsers'
    'DomainDuplicateObjects'
    
    ### Domain Controller
    'DCInformation'
    'DCWindowsRemoteManagement'
    'DCEventLogs'
    'DCOperatingSystem'
    'DCServices'
    'DCLDAP'
    'DCLDAPInsecureBindings'
    'DCPingable'
    'DCPorts'
    'DCRDPPorts'
    'DCRDPSecurity'
    'DCDiskSpace'
    'DCTimeSettings'
    'DCTimeSynchronizationInternal'
    'DCTimeSynchronizationExternal'
    'DCNetworkCardSettings'
    'DCWindowsUpdates'
    'DCWindowsRolesAndFeatures'
    'DCDnsResolveInternal'
    'DCDnsResolveExternal'
    'DCDnsNameServes'
    'DCSMBProtocols'
    'DCSMBShares'
    'DCSMBSharesPermissions'
    'DCDFS'
    'DCNTDSParameters'
    'DCGroupPolicySYSVOL'
    'DCLanManagerSettings'
    'DCDiagnostics'
    'DCLanManServer'
    'DCMSSLegacy'
    'DCFileSystem'
    'DCNetSessionEnumeration'
    'DCServiceWINRM'
    'DCUNCHardenedPaths'
    'DCDNSForwaders'
#>
$TestResults = Invoke-Testimo -HideSteps -ExtendedResults -Sources $Sources -ReportPath "$SaveFilePath\ADTestSummary_$((Get-Date -Format MMM-dd-yyyy).ToString()).html"
